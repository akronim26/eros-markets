// SPDX-License-Identifier: MIT
pragma solidity ^0.8.30;

import {ObservationStore} from "risk/pricing/ObservationStore.sol";
import {IMarketConfig} from "risk/interfaces/IMarketConfig.sol";

/// @notice Monad testnet receiver for pricefeed integration using real Eros ingress/store.
/// @dev No trading, collateral, settlement or oracle composition. Listing fields unrelated
///      to feeding are zero/disabled. This is explicitly a diagnostic receiver.
contract PricefeedTestnetReceiver is ObservationStore {
    error TestnetOnly();
    error InvalidConfiguration();
    error NotOwner();
    error AlreadyHalted();

    string public constant receiverKind = "EROS_PRICEFEED_TESTNET_DIAGNOSTIC_V1";
    address public immutable owner;
    bool private _earlyHalted;
    IMarketConfig.Listing private _listing;

    event DiagnosticHalt(uint64 timestamp);

    constructor(
        bytes32 marketId,
        bytes32 sourceId,
        address signer,
        bytes32 sourceRulesHash,
        uint256 depthNLots,
        uint256 maxSpreadWad,
        uint64 listedAt,
        uint64 scheduledT
    ) {
        if (block.chainid != 10143) revert TestnetOnly();
        if (marketId == bytes32(0) || sourceId == bytes32(0) || sourceRulesHash == bytes32(0)
            || signer == address(0) || depthNLots == 0 || maxSpreadWad > 1e18
            || listedAt > block.timestamp || scheduledT < uint256(listedAt) + 1 days
            || scheduledT <= block.timestamp
            || uint256(scheduledT) + 1 hours > uint256(listedAt) + 30 days) {
            revert InvalidConfiguration();
        }
        owner = msg.sender;
        _listing.marketId = marketId;
        _listing.listedAt = listedAt;
        _listing.scheduledT = scheduledT;
        _listing.indexSourceId = sourceId;
        _listing.indexSigner = signer;
        _listing.indexRulesHash = sourceRulesHash;
        _listing.depthNLots = depthNLots;
        _listing.maxSpreadWad = maxSpreadWad;
        _listing.invalidRule = IMarketConfig.InvalidRule(true, 1 hours, 5e17, 30 days);
        _initIngress(marketId, sourceId, DepthRule(depthNLots, maxSpreadWad));
        _configureSource(sourceId, signer, sourceRulesHash);
        _initStore(scheduledT);
    }

    function listing() external view returns (IMarketConfig.Listing memory) {
        return _listing;
    }

    function halted() external view returns (bool) {
        return _earlyHalted || block.timestamp >= _listing.scheduledT;
    }

    /// @notice Owner-only irreversible diagnostic early halt for lifecycle testing.
    ///         Signed source recording stays available, as in the real retained window.
    function haltDiagnostic() external {
        if (msg.sender != owner) revert NotOwner();
        if (_earlyHalted || block.timestamp >= _listing.scheduledT) revert AlreadyHalted();
        _earlyHalted = true;
        emit DiagnosticHalt(uint64(block.timestamp));
    }
}
