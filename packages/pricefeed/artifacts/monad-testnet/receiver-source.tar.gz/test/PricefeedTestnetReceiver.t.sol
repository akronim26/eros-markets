// SPDX-License-Identifier: MIT
pragma solidity ^0.8.30;

import {Test} from "forge-std/Test.sol";
import {PricefeedTestnetReceiver} from "../src/PricefeedTestnetReceiver.sol";
import {IPriceSource} from "risk/interfaces/IPriceSource.sol";
import {PriceIngress} from "risk/pricing/PriceIngress.sol";
import {IMarketConfig} from "risk/interfaces/IMarketConfig.sol";
import {PricingMath} from "risk/math/PricingMath.sol";

contract PricefeedTestnetReceiverTest is Test {
    uint256 private constant KEY = 0x123456; // Synthetic test-only signer, never deploy this key.
    bytes32 private constant MARKET = keccak256("test market");
    bytes32 private constant SOURCE = keccak256("test source");
    bytes32 private constant RULES = keccak256("test rules");
    PricefeedTestnetReceiver private receiver;

    function setUp() public {
        vm.chainId(10143);
        vm.warp(2_000_000);
        receiver = new PricefeedTestnetReceiver(MARKET, SOURCE, vm.addr(KEY), RULES,
            1_000_000, 5e16, 2_000_000, 2_000_000 + 2 days);
    }

    function obs(uint64 sequence, uint64 timestamp) private pure returns (IPriceSource.Observation memory) {
        return IPriceSource.Observation(MARKET, SOURCE, sequence, timestamp, timestamp,
            6e17, 59e16, 61e16, 2_000_000, 2_000_000, RULES);
    }

    function signature(IPriceSource.Observation memory o) private view returns (bytes memory) {
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(KEY, receiver.observationDigest(o));
        return abi.encodePacked(r, s, v);
    }

    function test_fullListingAndPinnedSource() public view {
        IMarketConfig.Listing memory l = receiver.listing();
        assertEq(l.marketId, MARKET);
        assertEq(l.indexSourceId, SOURCE);
        assertEq(l.indexSigner, vm.addr(KEY));
        assertEq(l.indexRulesHash, RULES);
        assertEq(l.depthNLots, 1_000_000);
        assertEq(l.invalidRule.captureGraceSecs, 3600);
        assertFalse(l.fundingEnabled);
        assertEq(receiver.owner(), address(this));
        assertTrue(receiver.sourceState(SOURCE).configured);
        assertFalse(receiver.halted());
    }

    function test_signedObservationAcceptedWithExactEventAndReplayRejected() public {
        IPriceSource.Observation memory o = obs(1, 2_000_000);
        bytes memory sig = signature(o);
        vm.expectEmit(true, false, false, true, address(receiver));
        emit IPriceSource.ObservationAccepted(SOURCE, 1, 2_000_000, 2_000_000,
            2_000_000, 6e17, true, receiver.observationDigest(o));
        receiver.submitObservation(o, sig);
        assertEq(receiver.sourceState(SOURCE).lastSequence, 1);
        vm.expectRevert(PriceIngress.DuplicateOrOldSequence.selector);
        receiver.submitObservation(o, sig);
    }

    function test_wrongSignerAndChainAndReceiverDomainRejected() public {
        IPriceSource.Observation memory o = obs(1, 2_000_000);
        bytes memory sig = signature(o);
        vm.chainId(31337);
        vm.expectRevert(PriceIngress.BadSignature.selector);
        receiver.submitObservation(o, sig);
        vm.chainId(10143);
        PricefeedTestnetReceiver other = new PricefeedTestnetReceiver(MARKET, SOURCE, vm.addr(KEY), RULES,
            1_000_000, 5e16, 2_000_000, 2_000_000 + 2 days);
        vm.expectRevert(PriceIngress.BadSignature.selector);
        other.submitObservation(o, sig);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(KEY + 1, receiver.observationDigest(o));
        vm.expectRevert(PriceIngress.BadSignature.selector);
        receiver.submitObservation(o, abi.encodePacked(r, s, v));
    }

    function test_mutatedAndWrongRulesPacketsRejected() public {
        IPriceSource.Observation memory o = obs(1, 2_000_000);
        bytes memory sig = signature(o);
        o.askDepthLots++;
        vm.expectRevert(PriceIngress.BadSignature.selector);
        receiver.submitObservation(o, sig);
        o.sourceRulesHash = bytes32(uint256(1));
        sig = signature(o);
        vm.expectRevert(PriceIngress.UnknownSource.selector);
        receiver.submitObservation(o, sig);
    }

    function test_futureAndBackwardsTimesRejected() public {
        IPriceSource.Observation memory o = obs(1, 2_000_001);
        bytes memory sig = signature(o);
        vm.expectRevert(PriceIngress.FutureTimestamp.selector);
        receiver.submitObservation(o, sig);
        o = obs(1, 2_000_000);
        receiver.submitObservation(o, signature(o));
        o = obs(2, 1_999_999);
        sig = signature(o);
        vm.expectRevert(PriceIngress.BackwardsObservation.selector);
        receiver.submitObservation(o, sig);
    }

    function test_completeTwapAndZeroInvalidCheckpoint() public {
        for (uint64 i; i <= 10; ++i) {
            vm.warp(2_000_000 + i * 30);
            IPriceSource.Observation memory o = obs(i + 1, uint64(block.timestamp));
            receiver.submitObservation(o, signature(o));
        }
        PricingMath.Twap memory tw = receiver.indexTwap300(2_000_300);
        assertTrue(tw.available);
        assertEq(tw.coveredSecs, 300);
        assertEq(tw.twapWad, 6e17);
        IPriceSource.Observation memory invalid = obs(12, 2_000_300);
        invalid.priceWad = 0;
        invalid.impactBidWad = 0;
        invalid.impactAskWad = 0;
        invalid.bidDepthLots = 100;
        vm.expectEmit(true, false, false, true, address(receiver));
        emit IPriceSource.ObservationAccepted(SOURCE, 12, 2_000_300, 2_000_300,
            2_000_300, 0, false, receiver.observationDigest(invalid));
        receiver.submitObservation(invalid, signature(invalid));
        tw = receiver.indexTwap300(2_000_310);
        assertFalse(tw.available);
        assertEq(tw.coveredSecs, 290);
    }

    function test_thirtySecondCarryDoesNotFillGap() public {
        IPriceSource.Observation memory o = obs(1, 2_000_000);
        receiver.submitObservation(o, signature(o));
        PricingMath.Twap memory tw = receiver.indexTwap300(2_000_300);
        assertFalse(tw.available);
        assertEq(tw.coveredSecs, 30);
    }

    function test_haltOwnerOnlyIrreversibleAndRecordingContinues() public {
        vm.prank(address(0xBAD));
        vm.expectRevert(PricefeedTestnetReceiver.NotOwner.selector);
        receiver.haltDiagnostic();
        receiver.haltDiagnostic();
        assertTrue(receiver.halted());
        vm.expectRevert(PricefeedTestnetReceiver.AlreadyHalted.selector);
        receiver.haltDiagnostic();
        IPriceSource.Observation memory o = obs(1, 2_000_000);
        receiver.submitObservation(o, signature(o));
        assertEq(receiver.sourceState(SOURCE).lastSequence, 1);
        vm.warp(2_000_000 + 2 days + 1);
        assertTrue(receiver.halted());
    }

    function test_scheduledHaltAtExactDeadline() public {
        vm.warp(2_000_000 + 2 days - 1);
        assertFalse(receiver.halted());
        vm.warp(2_000_000 + 2 days);
        assertTrue(receiver.halted());
    }

    function test_deploymentRejectsOtherChainsAndBadHorizon() public {
        vm.chainId(143);
        vm.expectRevert(PricefeedTestnetReceiver.TestnetOnly.selector);
        new PricefeedTestnetReceiver(MARKET, SOURCE, vm.addr(KEY), RULES,
            1_000_000, 5e16, 2_000_000, 2_000_000 + 2 days);
        vm.chainId(10143);
        vm.expectRevert(PricefeedTestnetReceiver.InvalidConfiguration.selector);
        new PricefeedTestnetReceiver(MARKET, SOURCE, vm.addr(KEY), RULES,
            1_000_000, 5e16, 2_000_000, 2_000_001);
    }
}
